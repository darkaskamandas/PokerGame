﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Poker
{
    public class Card
    {
        public string Rank { get; set; }
        public char Suit { get; set; }
    }
}